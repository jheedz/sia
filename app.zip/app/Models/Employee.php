<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Employee extends Model
{
    use HasFactory;

    // Menentukan nama tabel (opsional jika nama model & tabel sudah sinkron)
    protected $table = 'employees';

    // Izinkan kolom-kolom ini diisi oleh MoonShine
    protected $guarded = []; 

    // Jika kamu pakai kolom tanggal kustom, daftarkan di sini agar otomatis dikonversi jadi objek Carbon oleh Laravel
    protected $casts = [
        'joined_at' => 'date',
        'is_active' => 'boolean',
    ];

    public function attendances()
    {
        return $this->hasMany(Attendance::class);
    }
    
    public function position(): BelongsTo
    {
        return $this->belongsTo(Position::class);
    }
}