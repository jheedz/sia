<?php

declare(strict_types=1);

namespace App\MoonShine\Controllers;

use MoonShine\Contracts\Core\DependencyInjection\CrudRequestContract;
use MoonShine\Laravel\Http\Controllers\MoonShineController;
use Symfony\Component\HttpFoundation\Response;

final class AttendanceKioskController extends MoonShineController
{
    public function __invoke(CrudRequestContract $request): Response
    {
        // Examples

        // $this->toast('Hello world');
        // $request->getPage();
        // $request->getResource();

        /*
        // Render custom content
        return $this
            ->view('path_to_blade', ['param' => 'value'])
            ->setLayout('custom_layout')
            ->render();
        */

        return back();
    }
}
