<?php

declare(strict_types=1);

namespace App\MoonShine\Pages;

use MoonShine\Core\Pages\Page;
use MoonShine\UI\Components\Components;
use MoonShine\UI\Components\FormBuilder;
use MoonShine\UI\Fields\Select;

class AttendanceReportPage extends Page
{
    public function getTitle(): string
    {
        return $this->title ?: 'Cetak Laporan Absensi';
    }

    /**
     * Komponen komponen yang tampil di dalam Halaman Kustom
     */
    public function components(): array
    {
        // Menyusun daftar tahun (3 tahun terakhir hingga tahun ini)
        $currentYear = (int) date('Y');
        $years = [];
        for ($i = $currentYear; $i >= $currentYear - 3; $i--) {
            $years[$i] = (string) $i;
        }

        return [
            FormBuilder::make()
                ->action(route('admin.attendance.print')) // Arahkan ke route cetak kita
                ->method('GET')
                ->customAttributes(['target' => '_blank']) // Buka di tab baru agar halaman admin tidak hilang
                ->fields([
                    Select::make('Pilih Bulan', 'month')
                        ->options([
                            '1' => 'Januari', '2' => 'Februari', '3' => 'Maret',
                            '4' => 'April', '5' => 'Mei', '6' => 'Juni',
                            '7' => 'Juli', '8' => 'Agustus', '9' => 'September',
                            '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
                        ])
                        ->default((string) date('n'))
                        ->required(),

                    Select::make('Pilih Tahun', 'year')
                        ->options($years)
                        ->default((string) $currentYear)
                        ->required(),
                ])
                ->submit('Proses & Cetak Laporan', ['class' => 'btn-primary']),
        ];
    }
}