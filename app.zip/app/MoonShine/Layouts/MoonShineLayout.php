<?php

declare(strict_types=1);

namespace App\MoonShine\Layouts;

use App\MoonShine\Resources\AppMetric\AppMetricResource;
use App\MoonShine\Resources\EngineNotifReport\EngineNotifReportResource;
use App\MoonShine\Resources\MasterAplikasi\MasterAplikasiResource;
use App\MoonShine\Resources\MasterMetrik\MasterMetrikResource;
use App\MoonShine\Resources\ReportSource\ReportSourceResource;
use App\MoonShine\Resources\MoonShineUser\MoonShineUserResource;
use App\MoonShine\Resources\MoonShineUserRole\MoonShineUserRoleResource;
use App\MoonShine\Resources\MteleplusReport\MteleplusReportResource;
use App\MoonShine\Resources\TrxPbiLimitReport\TrxPbiLimitReportResource;
use App\MoonShine\Resources\TrxPbiSettlementReport\TrxPbiSettlementReportResource;
use MoonShine\ColorManager\ColorManager;
use MoonShine\ColorManager\Palettes\PurplePalette;
use MoonShine\Contracts\ColorManager\ColorManagerContract;
use MoonShine\Contracts\ColorManager\PaletteContract;
use MoonShine\Laravel\Layouts\AppLayout;
use MoonShine\MenuManager\MenuGroup;
use MoonShine\MenuManager\MenuItem;
use App\MoonShine\Resources\Employee\EmployeeResource;
use App\MoonShine\Resources\Attendance\AttendanceResource;
use App\MoonShine\Resources\Inventory\InventoryResource;
use App\MoonShine\Resources\Student\StudentResource;
use App\MoonShine\Resources\Position\PositionResource;


final class MoonShineLayout extends AppLayout
{
    /**
     * @var null|class-string<PaletteContract>
     */
    protected ?string $palette = PurplePalette::class;

    protected function assets(): array
    {
        return [
            ...parent::assets(),
        ];
    }

    protected function menu(): array
    {
        $isAdmin = static fn (): bool =>
            auth(moonshineConfig()->getGuard())->user()?->isSuperUser() ?? false;

        return [
            // Manajemen user — hanya admin
            MenuGroup::make('Manajemen', [
                MenuItem::make(MoonShineUserResource::class)->icon('users'),
                MenuItem::make(MoonShineUserRoleResource::class)->icon('shield-check'),
                MenuItem::make(PositionResource::class, 'Positions'),
            ])->icon('cog-6-tooth')->canSee($isAdmin),

            MenuGroup::make('Data Master', [
                MenuItem::make(InventoryResource::class, 'Inventories'),
                MenuItem::make(StudentResource::class, 'Students'),
                MenuItem::make(EmployeeResource::class, 'Employees'),
            ])->icon('presentation-chart-line'),
            MenuGroup::make('Reporting', [
                MenuItem::make('Laporan Absensi', \App\MoonShine\Pages\AttendanceReportPage::class)
                    ->icon('document-chart-bar'), 
            ])->icon('presentation-chart-line'),
            MenuItem::make(AttendanceResource::class, 'Attendances'),
        ];
    }

    /**
     * @param ColorManager $colorManager
     */
    protected function colors(ColorManagerContract $colorManager): void
    {
        parent::colors($colorManager);

        // $colorManager->primary('#00000');
    }
}
