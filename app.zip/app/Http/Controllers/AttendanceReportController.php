<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;
use App\Models\Attendance;
use Carbon\Carbon;

class AttendanceReportController extends Controller
{
    public function print(Request $request)
    {
        $request->validate([
            'month' => 'required|integer|between:1,12',
            'year' => 'required|integer',
        ]);

        $month = $request->month;
        $year = $request->year;
        
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

        // Ambil semua karyawan beserta data absennya di bulan tersebut
        $employees = Employee::with(['position', 'attendances' => function($query) use ($startDate, $endDate) {
            $query->whereBetween('date', [$startDate, $endDate]);
        }])->get();

        $monthName = $startDate->isoFormat('MMMM YYYY');

        return view('reports.attendance-print', compact('employees', 'monthName', 'startDate', 'endDate'));
    }
}