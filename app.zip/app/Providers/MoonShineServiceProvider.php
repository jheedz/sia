<?php

declare(strict_types=1);

namespace App\Providers;

use App\MoonShine\Resources\AppMetric\AppMetricResource;
use App\MoonShine\Resources\EngineNotifReport\EngineNotifReportResource;
use App\MoonShine\Resources\EngineNotifReport\Pages\EngineNotifReportFetchPage;
use App\MoonShine\Resources\MasterAplikasi\MasterAplikasiResource;
use App\MoonShine\Resources\MasterMetrik\MasterMetrikResource;
use App\MoonShine\Resources\ReportSource\ReportSourceResource;
use App\MoonShine\Resources\MoonShineUser\MoonShineUserResource;
use App\MoonShine\Resources\MoonShineUserRole\MoonShineUserRoleResource;
use App\MoonShine\Resources\MteleplusReport\MteleplusReportResource;
use App\MoonShine\Resources\MteleplusReport\Pages\MteleplusReportFetchPage;
use App\MoonShine\Resources\TrxPbiLimitReport\TrxPbiLimitReportResource;
use App\MoonShine\Resources\TrxPbiLimitReport\Pages\TrxPbiLimitReportFetchPage;
use App\MoonShine\Resources\TrxPbiSettlementReport\TrxPbiSettlementReportResource;
use App\MoonShine\Resources\TrxPbiSettlementReport\Pages\TrxPbiSettlementReportFetchPage;
use Illuminate\Support\ServiceProvider;
use MoonShine\Contracts\Core\DependencyInjection\CoreContract;
use MoonShine\Laravel\DependencyInjection\MoonShineConfigurator;
use MoonShine\Laravel\Models\MoonshineUser;
use MoonShine\Support\Enums\Ability;
use App\MoonShine\Resources\Employee\EmployeeResource;
use App\MoonShine\Resources\Attendance\AttendanceResource;
use App\MoonShine\Pages\AttendanceKiosk;
use App\MoonShine\Resources\Inventory\InventoryResource;
use App\MoonShine\Resources\Student\StudentResource;
use App\MoonShine\Resources\Position\PositionResource;
use App\MoonShine\Pages\AttendanceReportPage;

class MoonShineServiceProvider extends ServiceProvider
{
    // Resources yang hanya bisa diakses role Admin (id=1)
    private const ADMIN_ONLY_RESOURCES = [
        MoonShineUserResource::class,
        MoonShineUserRoleResource::class,
        MasterAplikasiResource::class,
        MasterMetrikResource::class,
        ReportSourceResource::class,
    ];

    /**
     * @param  CoreContract<MoonShineConfigurator>  $core
     */
    public function boot(CoreContract $core): void
    {
        $core
            ->resources([
                MoonShineUserResource::class,
                MoonShineUserRoleResource::class,
                MasterAplikasiResource::class,
                MasterMetrikResource::class,
                EngineNotifReportResource::class,
                MteleplusReportResource::class,
                TrxPbiLimitReportResource::class,
                TrxPbiSettlementReportResource::class,
                AppMetricResource::class,
                ReportSourceResource::class,
                EmployeeResource::class,
                AttendanceResource::class,
                InventoryResource::class,
                StudentResource::class,
                PositionResource::class,
            ])
            ->pages([
                ...$core->getConfig()->getPages(),
                EngineNotifReportFetchPage::class,
                MteleplusReportFetchPage::class,
                TrxPbiLimitReportFetchPage::class,
                TrxPbiSettlementReportFetchPage::class,
                AttendanceKiosk::class,
                AttendanceReportPage::class,
            ]);

        $core->getConfig()->authorizationRules(
            static function ($resource, $user, Ability $ability, $item): bool {
                if (! $user instanceof MoonshineUser) {
                    return true;
                }

                if ($user->isSuperUser()) {
                    return true;
                }

                return ! in_array(get_class($resource), self::ADMIN_ONLY_RESOURCES, true);
            }
        );
    }
    protected function pages(): array
    {
        return [
            // Daftarkan page laporan di sini agar rute URL-nya digenerate oleh MoonShine
            AttendanceReportPage::class, 
        ];
    }
}
